#ifndef COREADD_H
#define COREADD_H
class CoreAdd
{
private:


public:
    CoreAdd();
    long RandomNbrs();
};
#endif // COREADD_H
