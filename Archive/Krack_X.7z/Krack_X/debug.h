#include <iostream>
#include <vector>
#include <numeric>
#include <chrono>
#ifndef CORE_H
#define CORE_H

class Debug
{
private:

public:
    Debug();//Pas de crochet !

};

#endif // CORE_H
