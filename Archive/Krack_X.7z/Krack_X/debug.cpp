#include "debug.h"
#include <iostream>
#include <thread>
// Date constructor
Debug::Debug()
{

}

/*
 * auto current_time = std::chrono::system_clock::now();
auto duration_in_seconds = std::chrono::duration<double>(current_time.time_since_epoch());

double num_seconds = duration_in_seconds.count();
*/
